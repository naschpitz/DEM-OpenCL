var searchData=
[
  ['head',['head',['../class_rest_client_1_1_connection.html#a64f085227c8c4d47dc6c84fea4f71398',1,'RestClient::Connection::head()'],['../namespace_rest_client.html#a99dee400dfdab150b9fdce2ab6a0c2dc',1,'RestClient::head()']]],
  ['header_5fcallback',['header_callback',['../namespace_rest_client_1_1_helpers.html#a464be55c71cef59eebb53d922956a4d1',1,'RestClient::Helpers']]]
];
