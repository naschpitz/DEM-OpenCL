var searchData=
[
  ['post',['post',['../class_rest_client_1_1_connection.html#a76b11e6e01fb84cafdacf99e49aae6a7',1,'RestClient::Connection::post()'],['../namespace_rest_client.html#a7de7aa2d333b6e7c5f2c2726d4e5485e',1,'RestClient::post()']]],
  ['put',['put',['../class_rest_client_1_1_connection.html#af1a30c5aa6a646e6bad4caf2abb7084c',1,'RestClient::Connection::put()'],['../namespace_rest_client.html#ac180f6320d47cad592399378f8c45f7a',1,'RestClient::put()']]]
];
